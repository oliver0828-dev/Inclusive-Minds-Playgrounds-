import SwiftUI

struct PopUpInfoView: View {
    var titleName: String = "Title"
    var description: String = """
    LOREM IPSUM
    """
    var body: some View {
        NavigationView{
            VStack{
                Rectangle()
                    .frame(width: 100, height: 5)
                    .cornerRadius(10)
                    .padding()
                HStack{
                    Text(titleName)
                        .font(.title)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.leading)
                    Spacer()
                }
                .padding()
                Text(description)
                    .fontWeight(.medium)
                    .font(.subheadline)
                    .padding()
                Spacer()
                Spacer()
            }
        }
    }
}
