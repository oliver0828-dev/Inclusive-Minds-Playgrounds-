import SwiftUI

struct IRView: View {
    var body: some View {
        NavigationView {
            VStack {
                Image("ir")
                    .resizable()
                    .frame(width: 300, height: 200)
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(10)
                Text("Image: UNESCO")
                    .font(.caption)
                    .foregroundStyle(Color.gray)
                Text("""
                     This occurs when individuals express discriminatory beliefs, attitudes, or behaviors towards people of a different race. Examples include using racial slurs, making derogatory comments, or displaying prejudice against someone based on their race.
                     """)
                .padding()
                Spacer()
                PopUpView(ViewName: AnyView(LMIRView()))
                Spacer()
            }.padding()
                .navigationTitle("Individual Racism")
        }
    }
}
