import SwiftUI

struct SOARIntroView: View {
    var body: some View {
        NavigationView{
            VStack {
                Rectangle()
                    .frame(width: 100, height: 5)
                    .cornerRadius(10)
                HStack{
                    Text("What is SOAR")
                        .font(.title)
                        .fontWeight(.bold)
                    Spacer()
                }
                .padding()
                
                Image("soar")
                    .resizable()
                    .frame(width: 250, height: 250)
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(10)
                Text("Image: Daegu International School")
                    .font(.caption)
                    .foregroundStyle(Color.gray)
                
                Text("""
                     This involves the belief in the superiority of one culture over others, leading to the devaluation or marginalization of other cultures. It can be seen in cultural appropriation, where aspects of a marginalized culture are adopted by a dominant group without proper recognition or respect.
                     """)
                .padding()
                Spacer()
            }.padding()
        }
    }
}
