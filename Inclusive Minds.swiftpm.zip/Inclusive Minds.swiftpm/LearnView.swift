import SwiftUI

struct LearnView: View {
    let columns = [GridItem(.flexible()), GridItem(.flexible())]
    
    var body: some View {
        
        VStack{
            Spacer()
            Text("Let's Learn!")
                .font(.title)
                .fontWeight(.semibold)
                .padding()
            LazyVGrid(columns: columns){
                BoxView(ViewName: AnyView(CRView()), ImageName: "Group 2", TextName: "Cultural Racism", ColorStyle: Color.purple)
                BoxView(ViewName: AnyView(MEView()), ImageName: "Group 1", TextName: "Microaggression", ColorStyle: Color.pink)
                BoxView(ViewName: AnyView(IRView()), ImageName: "Group 4", TextName: "Individual Racism", ColorStyle: Color.orange)
                BoxView(ViewName: AnyView(SRView()), ImageName: "Group 3", TextName: "Structural Racism", ColorStyle: Color.blue)
                
            }
            SOARPopUpView()
                .padding(.top)
            Spacer()
        }
        
    }
    
    
}

#Preview {
    LearnView()
}


struct BoxView: View {
    var ViewName: AnyView
    var ImageName: String
    var TextName: String
    var ColorStyle: Color
    
    var body: some View {
        NavigationLink(destination: ViewName) {
            ZStack {
                Rectangle()
                    .frame(width: 150, height: 150)
                    .cornerRadius(10)
                    .foregroundStyle(ColorStyle)
                
                VStack {
                    Image(ImageName)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 50, height: 50)
                        .foregroundStyle(Color.white)
                        .padding(2)
                    
                    Text(TextName)
                        .foregroundStyle(Color.white)
                        .font(.title3)
                        .multilineTextAlignment(.center)
                        .fontWeight(.medium)
                        .frame(width: 140)
                }
            }
        }
    }
}

struct IntroSOARView: View{
    var body: some View{
        ZStack{
            Rectangle()
                .frame(width: 250,height: 50)
                .cornerRadius(50)
                .foregroundStyle(Color.red)
            HStack{
                Text("Associated with SOAR")
                    .foregroundStyle(Color.white)
                    .fontWeight(.medium)
                Image("soar")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 40, height: 40)
                
            }
        }
    }
}

struct SOARPopUpView: View {
    @State private var showingPopover = false
    var body: some View {
        Button(action: {showingPopover = true}){
            Text("Associated with SOAR")
                .foregroundStyle(Color.white)
                .fontWeight(.medium)
            Image("soar")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 40, height: 40)
            
        }.popover(isPresented: $showingPopover) {
            SOARIntroView()
        }
        .frame(width: 250,height: 50)
        .background(Color.red)
        .cornerRadius(50)
    }
}
